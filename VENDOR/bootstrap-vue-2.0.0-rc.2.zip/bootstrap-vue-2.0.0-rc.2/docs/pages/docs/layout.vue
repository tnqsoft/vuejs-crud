<template>
</template>

<script>
// Add redirect from old URL to new one
export default {
  fetch ({ redirect }) {
    redirect('/docs/components/layout')
  }
}
</script>
