<template>
</template>

<script>
export default {
  fetch({ redirect }) {
    redirect("/docs/reference/color-variants");
  }
};
</script>
