<template>
</template>

<script>
export default {
  fetch({ redirect }) {
    redirect("/docs/components/alert");
  }
};
</script>
