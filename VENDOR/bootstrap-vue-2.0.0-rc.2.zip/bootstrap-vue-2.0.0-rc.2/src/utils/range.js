/**
 * @param {number} length
 * @return {Array}
 */
export default length => Array.apply(null, { length })
