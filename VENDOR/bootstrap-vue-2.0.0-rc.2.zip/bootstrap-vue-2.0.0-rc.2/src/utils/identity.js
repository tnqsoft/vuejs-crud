export default function identity (x) {
  return x
}
