window.app = new Vue({
  el: '#app',
  data: {
    state: 'please_accept',
    checked: []
  }
})
