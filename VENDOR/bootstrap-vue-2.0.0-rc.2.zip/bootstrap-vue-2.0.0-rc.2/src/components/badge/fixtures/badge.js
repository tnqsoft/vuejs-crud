window.app = new Vue({
  el: '#app',
  data () {
    return {
      variants: [
        'secondary',
        'primary',
        'success',
        'info',
        'warning',
        'danger',
        'dark',
        'light'
      ]
    }
  }
})
