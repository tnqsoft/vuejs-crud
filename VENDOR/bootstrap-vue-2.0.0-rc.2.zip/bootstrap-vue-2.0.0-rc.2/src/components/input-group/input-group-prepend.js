import InputGroupAddon, { propsFactory } from './input-group-addon'

export default {
  functional: true,
  props: propsFactory(false),
  render: InputGroupAddon.render
}
