window.app = new Vue({
  el: '#app',
  data: {
    currentPage: 3
  }
})
