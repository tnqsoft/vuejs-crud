window.app = new Vue({
  el: '#app',
  data: {
    file: null,
    file2: null,
    file3: null,
    files: []
  }
})
