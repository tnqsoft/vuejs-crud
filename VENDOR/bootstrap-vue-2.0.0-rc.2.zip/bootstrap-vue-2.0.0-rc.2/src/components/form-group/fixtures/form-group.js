window.app = new Vue({
  el: '#app',
  data: {
    text: ''
  }
})
