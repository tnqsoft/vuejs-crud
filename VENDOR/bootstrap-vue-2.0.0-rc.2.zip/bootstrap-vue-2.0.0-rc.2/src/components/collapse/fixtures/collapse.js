window.app = new Vue({
  el: '#app',
  data: {
    showCollapse: true
  }
})
