# BootstrapVue tests

Tests are moved into `src/**/*.spec` files.
